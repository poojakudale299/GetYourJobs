using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using TopJobs.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using TopJobs.Data;
using TopJobs.Areas.Identity.Data;
using System.Configuration;
namespace TopJobs
{
    public class Startup
    {
        public readonly IConfiguration Configuration;

      

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            
            services.AddControllersWithViews();
            services.AddControllersWithViews();
            services.AddScoped<IJobRepo, JobRepo>();
            services.AddScoped<IIndustryRepo, IndustryRepo>();
            services.AddScoped<IApplicantRepo, ApplicantRepo>();
            services.AddScoped<IServiceRepo, ServiceRepo>();
            services.AddDefaultIdentity<TopJobsUser>().AddEntityFrameworkStores<TopJobsContext>();

           
            services.AddDbContext<JobDbContext>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")).EnableSensitiveDataLogging();
            });
            services.AddScoped<ShoppingCart>(sp => ShoppingCart.GetCart(sp));
            services.AddHttpContextAccessor();
            services.AddSession();
            services.AddAuthentication().AddLinkedIn(options =>
            {
                options.ClientId = Configuration["Authentication:LinkedIn:ClientId"];
                options.ClientSecret = Configuration["Authentication:LinkedIn:ClientSecret"];
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseFileServer();
            //app.UseStaticFiles();
            app.UseRouting();
            app.UseSession();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
                endpoints.MapRazorPages();
            });
        }
    }
}
