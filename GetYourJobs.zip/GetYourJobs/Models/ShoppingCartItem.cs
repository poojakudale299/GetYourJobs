﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public class ShoppingCartItem
    {
        public int ShoppingCartItemId { get; set; }
        public Service Service { get; set; }
        public int SubscrptionPeriod { get; set; }
        public string ShoppingCartId { get; set; }
    }
}
