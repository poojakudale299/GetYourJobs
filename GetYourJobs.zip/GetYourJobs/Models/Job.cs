﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public class Job
    {
        [Key]
       public int JobId { get; set; }
        
        public string Profile { get; set; }
        //public List<string> Skills { get; set; }
        public string JD { get; set; }
      
        public string Location { get; set; }
        
        public int minExperience { get; set; }

        public int maxExperience { get; set; }

        //public int companyId { get; set; }
        public string Employer { get; set; }
       // public string companyUrl { get; set; }
        public double CTC { get; set; }

        public Industry industry { get; set; }

        
        public int industryId { get; set; }
    }
}
