﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public  interface IServiceRepo
    {
        public IEnumerable<Service> GetListOfServices { get; }

        Service GetServiceByName(string serviceName);

    }
}
