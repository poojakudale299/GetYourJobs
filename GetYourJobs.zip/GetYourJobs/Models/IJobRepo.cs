﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public interface IJobRepo
    {
        IEnumerable<Job> GetListOfJobs { get; }
        Job GetJobByRole(string role);

        Job GetJobById(int id);
    }
}
