﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public class Applicant
    {
        [Key]
        public int Applicantid { get; set; }

        [Required(ErrorMessage ="Please enter your First Name!")]
        [StringLength(20)][MaxLength(20)]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter your Last Name!")]
        [StringLength(20)]
        [MaxLength(20)]
        public string LastName { get; set; }
        
        [Required(ErrorMessage ="Please enter your contact number!")]
        [Display(Name ="Mobile Number")][DataType(DataType.PhoneNumber)]
        public string PhoneNo { get; set; }

        [Required(ErrorMessage ="Please enter your Email Id!")]
        [Display(Name ="Email Id")][DataType(DataType.EmailAddress)]
        public string EmailId { get; set; }

        [Required]
        public string Qualification { get; set; }

        [Required][Display(Name ="Work Experience")]
        public string Experience { get; set; }

        [Required(ErrorMessage = "Please enter Skills!")]
        public string Skills { get; set; }

        [Required(ErrorMessage = "Please enter Age!")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Please enter pincode!")]
        public string pincode { get; set; }

        [Required(ErrorMessage = "Please enter City!")]
        public string city { get; set; }

        [Required(ErrorMessage = "Please enter State!")]
        public string State { get; set; }

        [Required(ErrorMessage = "Please enter Country!")]

        public string Country { get; set; }

        [BindNever]
        [ScaffoldColumn(false)]
        public DateTime AppliedForJob { get; set; }
    }
}
