﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public class InMemoryIndustryRepo : IIndustryRepo
    {
        public IEnumerable<Industry> GetAllIndustries => new List<Industry>
        {
            new Industry{IndustryId=1,IndustryType="Banking"},
                new Industry{ IndustryId=2,IndustryType="IT services"},
                new Industry{IndustryId=3,IndustryType="Recruitment"}
        };
    }
}
