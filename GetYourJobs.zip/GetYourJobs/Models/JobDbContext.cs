﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace TopJobs.Models
{
    public class JobDbContext:DbContext
    {
        public JobDbContext(DbContextOptions<JobDbContext> options):base(options)
        {

        }

        public DbSet<Job> Jobs { get; set; }
        public DbSet<Industry> Industries { get; set; }
        public DbSet<Applicant> Applicants { get; set; }

        public DbSet<Service> Services { get; set; }

        public DbSet<ShoppingCartItem> ShoppingCartItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder) 
        {
            modelBuilder.Entity<Industry>().HasData(new Industry { IndustryId = 1, IndustryType = "Mechanical" });
            modelBuilder.Entity<Industry>().HasData(new Industry { IndustryId = 2, IndustryType = "Sales" });
            modelBuilder.Entity<Industry>().HasData(new Industry { IndustryId = 3, IndustryType = "Consultant" });
            modelBuilder.Entity<Industry>().HasData(new Industry { IndustryId = 4, IndustryType = "Government" });


            modelBuilder.Entity<Job>().HasData(
                new Job
                {
                    JobId = 1,
                    Profile = "Consultant",
                    JD = "Communication skills",
                    Employer = "ZS",
                    Location = "Bangalore",
                    minExperience = 6,maxExperience=7,
                    CTC = 7,
                    //Skills = null,
                    industryId = 3
                }
                );
            modelBuilder.Entity<Job>().HasData(
                new Job
                {
                    JobId = 4,
                    Profile = "Consultant",
                    JD = "Communication skills",
                    Employer = "ZS",
                    Location = "Bangalore",
                    minExperience = 6,
                    maxExperience = 7,
                    CTC = 7,
                    //Skills = null,
                    industryId = 3
                }
                );
            //modelBuilder.Entity<Job>().HasMany(p=>p.industryId).WithOne().HasForeignKey(prop=>prop.industryId)

            modelBuilder.Entity<Job>().HasData(
                new Job
                {
                    JobId = 2,
                    Profile = "Engineer",
                    JD = "Knowledge in Machine designs",
                    Employer = "TATA motors",
                    Location = "Mumbai",
                    minExperience = 8,maxExperience=10,
                    CTC = 9,
                    //Skills = null,
                    industryId = 1
                }
                );
            modelBuilder.Entity<Job>().HasData(
               new Job
               {
                   JobId = 5,
                   Profile = "Engineer",
                   JD = "Knowledge in Machine designs",
                   Employer = "TATA motors",
                   Location = "Mumbai",
                   minExperience = 8,
                   maxExperience = 10,
                   CTC = 9,
                    //Skills = null,
                    industryId = 1
               }
               );

            modelBuilder.Entity<Job>().HasData(
                new Job
                {
                    JobId = 3,
                    Profile = "Sales",
                    JD = "Good Bussiness understanding ",
                    Employer = "IDEA",
                    Location = "Indore",
                    minExperience = 0,maxExperience=6,
                    CTC = 4,
                    //Skills = null,
                    industryId = 2
                }
                );

            modelBuilder.Entity<Job>().HasData(
                new Job
                {
                    JobId = 6,
                    Profile = "Sales",
                    JD = "Good Bussiness understanding ",
                    Employer = "IDEA",
                    Location = "Indore",
                    minExperience = 0,
                    maxExperience = 6,
                    CTC = 4,
                    //Skills = null,
                    industryId = 2
                }
                );
            modelBuilder.Entity<Applicant>().ToTable("Applicant");

            modelBuilder.Entity<Service>().HasData(
                new Service
                { 
                    ServiceId=1,
                    ServiceName= "Advance ",
                    ShortDescription = "Get help from experts to crack interview",
                    LongDescription = "Get your job ",
                    Benifits = "Advance Version",
                    ServicePrice = 300,
                    SubscriptionDurationInMonths = 1
                }
            );
            modelBuilder.Entity<Service>().HasData(
                new Service
                {
                    ServiceId = 2,
                    ServiceName = "Premium",
                    ShortDescription = "Previous interview experiences and tips",
                    LongDescription = "Learn from the experiences of others and improve yourself",
                    Benifits = "Prime Version",
                    ServicePrice = 450 ,
                    SubscriptionDurationInMonths = 1
                }
            );
            modelBuilder.Entity<Service>().HasData(
      new Service
      {
          ServiceId = 3,
          ServiceName = "Advance++ ",
          ShortDescription = "Get help from experts to crack interview and preparation study material",
          LongDescription = "Get your job ",
          Benifits = "Advance Version",
          ServicePrice = 1000,
          SubscriptionDurationInMonths = 6
      }
  );
            modelBuilder.Entity<Service>().HasData(
                new Service
                {
                    ServiceId = 4,
                    ServiceName = "Premium++",
                    ShortDescription = "Previous interview experiences  and preparation study material",
                    LongDescription = "Learn from the experiences of others and improve yourself",
                    Benifits = "Prime Version",
                    ServicePrice = 1500,
                    SubscriptionDurationInMonths = 6
                }
            );

        }
    }
}
