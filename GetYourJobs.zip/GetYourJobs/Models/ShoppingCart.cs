﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TopJobs.Models;

namespace TopJobs.Models
{
    public class ShoppingCart
    {
        private readonly JobDbContext _jobDbContext;

        public string ShoppingCartId { get; set; }

        public List<ShoppingCartItem> ShoppingCartItems { get; set; }

        public ShoppingCart(JobDbContext jobDbContext)
        {
            _jobDbContext = jobDbContext;
        }

        //GetCart/AddtoCart/RemoveFromcart/GetShoppingitems/clear cart/gettotal

        public static ShoppingCart GetCart(IServiceProvider services)
        {
            ISession session = services.GetRequiredService<IHttpContextAccessor>()?.HttpContext.Session;
            var context = services.GetService<JobDbContext>();

            string cartId = session.GetString("CartId") ?? Guid.NewGuid().ToString();
            session.SetString("CartId", cartId);
            return new ShoppingCart(context) { ShoppingCartId = cartId };

        }

        public List<ShoppingCartItem> GetShoppingCartItems()
        {
            return ShoppingCartItems ?? (
                ShoppingCartItems = _jobDbContext.ShoppingCartItems.Where(c => c.ShoppingCartId == ShoppingCartId).Include(s => s.Service).ToList());
            // return _jobDbContext.ShoppingCartItems.ToList();
        }

        public void AddToCart(Service service, int SubscrptionPeriod)
        {

            var shoppingCartItem =
                _jobDbContext.ShoppingCartItems.SingleOrDefault(
                    s => s.Service.ServiceId == service.ServiceId && s.ShoppingCartId == ShoppingCartId);
            if (shoppingCartItem == null)
            {
                shoppingCartItem = new ShoppingCartItem
                {

                    ShoppingCartId = ShoppingCartId,
                    Service = service,
                    SubscrptionPeriod = 1
                };
                _jobDbContext.ShoppingCartItems.Add(shoppingCartItem);
            }
            else
            {
                shoppingCartItem.SubscrptionPeriod += 1;
            }
            _jobDbContext.SaveChanges();
        }

        public void RemoveFromCart(Service service)
        {
            var shoppingCartItem =
               _jobDbContext.ShoppingCartItems.SingleOrDefault(
                   s => s.Service.ServiceId == service.ServiceId && s.ShoppingCartId == ShoppingCartId);
            if (shoppingCartItem == null)
                return;
            else if (shoppingCartItem.SubscrptionPeriod > 1)
            {
                shoppingCartItem.SubscrptionPeriod -= 1;
            }
            else
            {
                _jobDbContext.ShoppingCartItems.Remove(shoppingCartItem);
            }
            _jobDbContext.SaveChanges();
        }
        public decimal GetShoppingCartTotal()
        {
            var total = _jobDbContext.ShoppingCartItems.Where(c => c.ShoppingCartId == ShoppingCartId)
                .Select(c => c.Service.ServicePrice * c.SubscrptionPeriod).Sum();

            return total;
        }

        public decimal GetShooppingCartTootal()
        {
            var shoppingCartItemsList = ShoppingCartItems ?? (
                 ShoppingCartItems = _jobDbContext.ShoppingCartItems.Where(c => c.ShoppingCartId == ShoppingCartId).Include(s => s.Service).ToList());

            //var shoppingCartItemsList = _jobDbContext.ShoppingCartItems.ToList();
            decimal total = 0;
            if (shoppingCartItemsList == null)
                return 100;
            foreach (var item in shoppingCartItemsList)
            {
                total = total + (item.SubscrptionPeriod / 1 * item.Service.ServicePrice);
            }
            return total;


            // var total = _jobDbContext.ShoppingCartItems.Where(c => c.ShoppingCartId == ShoppingCartId)
            //  .Select(c => c.SubscrptionPeriod* c.Service.ServicePrice).Sum();

            //return total;
        }

        //trying 

        

    }
}
