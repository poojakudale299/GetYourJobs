﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public class ServiceRepo:IServiceRepo
    {
        private readonly JobDbContext _jobDbContext;

        public ServiceRepo(JobDbContext jobDb)
        {
            _jobDbContext = jobDb;
        }

        public IEnumerable<Service> GetListOfServices => _jobDbContext.Services;

        public Service GetServiceByName(string serviceName)
        {
            return _jobDbContext.Services.FirstOrDefault<Service>(s=>s.ServiceName==serviceName);
        }
    }
}
