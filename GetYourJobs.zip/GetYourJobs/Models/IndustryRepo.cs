﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public class IndustryRepo : IIndustryRepo
    {

        private readonly JobDbContext _jobDbContext;

        public IndustryRepo(JobDbContext jobDb)
        {
            _jobDbContext = jobDb;
        }
        public IEnumerable<Industry> GetAllIndustries => _jobDbContext.Industries;
    }
}
