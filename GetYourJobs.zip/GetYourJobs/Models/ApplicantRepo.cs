﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public class ApplicantRepo:IApplicantRepo
    {

        private readonly JobDbContext _jobDbContext;

        public ApplicantRepo(JobDbContext jobDb)
        {
            _jobDbContext = jobDb;
        }

        public IEnumerable<Applicant> GetListOfApplicants => _jobDbContext.Applicants;
    }
}
