﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public class JobRepo : IJobRepo
    {
        private readonly JobDbContext _jobDbContext;

        public JobRepo(JobDbContext jobDb)
        {
            _jobDbContext = jobDb;
        }
        public IEnumerable<Job> GetListOfJobs => _jobDbContext.Jobs.Include(i => i.industry);
        

        public Job GetJobByRole(string role)
        {
            return _jobDbContext.Jobs.FirstOrDefault<Job>(j => j.Profile == role);
        }

        public Job GetJobById(int id)
        {
            return _jobDbContext.Jobs.FirstOrDefault<Job>(j => j.JobId == id);
        }
    }
}
