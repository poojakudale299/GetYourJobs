﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public class Service
    {
        public int ServiceId { get; set; }

        public string ServiceName { get; set; }
        public string ShortDescription { get; set; }
        public string LongDescription { get; set; }

        public decimal ServicePrice { get; set; }

        public string Benifits { get; set; }
        public int SubscriptionDurationInMonths { get; set; }
    }
}
