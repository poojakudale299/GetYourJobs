﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.Models
{
    public class InMemoryJobRepo : IJobRepo
    {
        public List<Job> _Jobs;


        public InMemoryJobRepo()
        {
            _Jobs = new List<Job> {
            new Job
            {
                JobId = 1,
               Profile = "HR Executive",
                JD = "Identifying hiring needs, Sourcing candidates through databases and social media, conducting interviews, resume reviewing, scheduling interviews, preparing candidates for interviews, collaborating with hiring managers, and the best part Extending offers & On boarding the candidates",
                Location = "Gurgaon",
                minExperience = 6,
                CTC = 7,
                //Skills = new List<string>()
                //{
                  // new string("IT Recruitment"),new string("Conducting Interviews"),new string("Interview scheduling")
                //},
                industryId=2
                // = "Sales Executive Activities, Business Development, Software Engineering, Sales Management, Marketing, Customer Support Operations, Telecalling, Ux, Ui"
            }
            };

        }

        public IEnumerable<Job> GetListOfJobs 
        {
            get
            {
                return _Jobs;

            }
        }

        public Job GetJobById(int id)
        {
            throw new NotImplementedException();
        }

        public Job GetJobByRole(string role)
        {
            throw new NotImplementedException();
        }
        
        
    }



}
