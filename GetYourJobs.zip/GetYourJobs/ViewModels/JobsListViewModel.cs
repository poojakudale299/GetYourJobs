﻿using TopJobs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.ViewModels
{
    public class JobsListViewModel
    {
        public IEnumerable<Job> Jobs { get; set; }

        public string CurrentIndustry { get; set; }
    }
}
