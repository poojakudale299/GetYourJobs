﻿using TopJobs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TopJobs.ViewModels
{
    public class HomeViewModel
    {
        public IEnumerable<Job> HighestPayingJobs { get; set; }
    }
}
