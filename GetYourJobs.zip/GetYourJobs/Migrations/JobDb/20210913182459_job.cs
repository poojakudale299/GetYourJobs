﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TopJobs.Migrations.JobDb
{
    public partial class job : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Applicant",
                columns: table => new
                {
                    Applicantid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(maxLength: 20, nullable: false),
                    LastName = table.Column<string>(maxLength: 20, nullable: false),
                    PhoneNo = table.Column<string>(nullable: false),
                    EmailId = table.Column<string>(nullable: false),
                    Qualification = table.Column<string>(nullable: false),
                    Experience = table.Column<string>(nullable: false),
                    Skills = table.Column<string>(nullable: false),
                    Age = table.Column<int>(nullable: false),
                    pincode = table.Column<string>(nullable: false),
                    city = table.Column<string>(nullable: false),
                    State = table.Column<string>(nullable: false),
                    Country = table.Column<string>(nullable: false),
                    AppliedForJob = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Applicant", x => x.Applicantid);
                });

            migrationBuilder.CreateTable(
                name: "Industries",
                columns: table => new
                {
                    IndustryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IndustryType = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Industries", x => x.IndustryId);
                });

            migrationBuilder.CreateTable(
                name: "Services",
                columns: table => new
                {
                    ServiceId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ServiceName = table.Column<string>(nullable: true),
                    ShortDescription = table.Column<string>(nullable: true),
                    LongDescription = table.Column<string>(nullable: true),
                    ServicePrice = table.Column<decimal>(nullable: false),
                    Benifits = table.Column<string>(nullable: true),
                    SubscriptionDurationInMonths = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Services", x => x.ServiceId);
                });

            migrationBuilder.CreateTable(
                name: "Jobs",
                columns: table => new
                {
                    JobId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Profile = table.Column<string>(nullable: true),
                    JD = table.Column<string>(nullable: true),
                    Location = table.Column<string>(nullable: true),
                    minExperience = table.Column<int>(nullable: false),
                    maxExperience = table.Column<int>(nullable: false),
                    Employer = table.Column<string>(nullable: true),
                    CTC = table.Column<double>(nullable: false),
                    industryId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Jobs", x => x.JobId);
                    table.ForeignKey(
                        name: "FK_Jobs_Industries_industryId",
                        column: x => x.industryId,
                        principalTable: "Industries",
                        principalColumn: "IndustryId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ShoppingCartItems",
                columns: table => new
                {
                    ShoppingCartItemId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ServiceId = table.Column<int>(nullable: true),
                    SubscrptionPeriod = table.Column<int>(nullable: false),
                    ShoppingCartId = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ShoppingCartItems", x => x.ShoppingCartItemId);
                    table.ForeignKey(
                        name: "FK_ShoppingCartItems_Services_ServiceId",
                        column: x => x.ServiceId,
                        principalTable: "Services",
                        principalColumn: "ServiceId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Industries",
                columns: new[] { "IndustryId", "IndustryType" },
                values: new object[,]
                {
                    { 1, "Mechanical" },
                    { 2, "Sales" },
                    { 3, "Consultant" },
                    { 4, "Government" }
                });

            migrationBuilder.InsertData(
                table: "Services",
                columns: new[] { "ServiceId", "Benifits", "LongDescription", "ServiceName", "ServicePrice", "ShortDescription", "SubscriptionDurationInMonths" },
                values: new object[,]
                {
                    { 1, "Advance Version", "Get your job ", "Advance ", 300m, "Get help from experts to crack interview", 1 },
                    { 2, "Prime Version", "Learn from the experiences of others and improve yourself", "Primium", 450m, "Previous interview experiences and tips", 1 },
                    { 3, "Advance Version", "Get your job ", "Advance++ ", 1000m, "Get help from experts to crack interview and preparation study material", 6 },
                    { 4, "Prime Version", "Learn from the experiences of others and improve yourself", "Primium", 1500m, "Previous interview experiences  and preparation study material", 6 }
                });

            migrationBuilder.InsertData(
                table: "Jobs",
                columns: new[] { "JobId", "CTC", "Employer", "JD", "Location", "Profile", "industryId", "maxExperience", "minExperience" },
                values: new object[,]
                {
                    { 2, 9.0, "TATA motors", "Knowledge in Machine designs", "Mumbai", "Engineer", 1, 10, 8 },
                    { 5, 9.0, "TATA motors", "Knowledge in Machine designs", "Mumbai", "Engineer", 1, 10, 8 },
                    { 3, 4.0, "IDEA", "Good Bussiness understanding ", "Indore", "Sales", 2, 6, 0 },
                    { 6, 4.0, "IDEA", "Good Bussiness understanding ", "Indore", "Sales", 2, 6, 0 },
                    { 1, 7.0, "ZS", "Communication skills", "Bangalore", "Consultant", 3, 7, 6 },
                    { 4, 7.0, "ZS", "Communication skills", "Bangalore", "Consultant", 3, 7, 6 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Jobs_industryId",
                table: "Jobs",
                column: "industryId");

            migrationBuilder.CreateIndex(
                name: "IX_ShoppingCartItems_ServiceId",
                table: "ShoppingCartItems",
                column: "ServiceId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Applicant");

            migrationBuilder.DropTable(
                name: "Jobs");

            migrationBuilder.DropTable(
                name: "ShoppingCartItems");

            migrationBuilder.DropTable(
                name: "Industries");

            migrationBuilder.DropTable(
                name: "Services");
        }
    }
}
