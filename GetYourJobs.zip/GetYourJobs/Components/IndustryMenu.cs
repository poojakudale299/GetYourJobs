﻿using TopJobs.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EkamArtMBProj.Components
{
    public class IndustryMenu:ViewComponent
    {
        private IIndustryRepo _industryRepo;
        //DI
        public IndustryMenu(IIndustryRepo industryRepo)
        {
            _industryRepo = industryRepo;

        }
        public IViewComponentResult Invoke()
        {
            var industries = _industryRepo.GetAllIndustries.OrderBy(i => i.IndustryType);
            return View(industries);
        }
    }
}
