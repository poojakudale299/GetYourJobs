﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TopJobs.Models;
using TopJobs.ViewModels;

namespace TopJobs.Components
{
    public class CartIcon:ViewComponent
    {
        private readonly ShoppingCart _shoppingCart;
        //DI
        public CartIcon(ShoppingCart shoppingCart)
        {
            _shoppingCart = shoppingCart;

        }

        public IViewComponentResult Invoke()
        {
            var services = _shoppingCart.GetShoppingCartItems();
            _shoppingCart.ShoppingCartItems = services;

            var shoppingCartViewModel = new ShoppingCartViewModel
            {
                ShoppingCart = _shoppingCart,
                ShoppingCartTotal = _shoppingCart.GetShoppingCartTotal()
            };

            return View(shoppingCartViewModel);
        }
    }
}
