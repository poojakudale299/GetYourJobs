﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace TopJobs.TagHelpers
{
    public class EmailTagHelper:TagHelper
    {
        public string address { get; set; }
        public string content { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "a";
            output.Attributes.SetAttribute("href", "mailto:" + address);
            output.Content.SetContent(content);
            //base.Process(context, output);
        }
    }
}
