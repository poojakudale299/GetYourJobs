﻿using TopJobs.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TopJobs.Models;
using Microsoft.EntityFrameworkCore;

namespace TopJobs.Controllers
{
    public class JobsController : Controller
    {
        
        private readonly IJobRepo _jobRepo;
        private readonly IIndustryRepo _industryRepo;
        private readonly JobDbContext _context;
        //Dependency Injection
        public JobsController(IJobRepo jobRepo, IIndustryRepo industryRepo,JobDbContext context)
        {
            _jobRepo = jobRepo;
            _industryRepo = industryRepo;
            _context = context;

        }
        /*
        [HttpGet]
        public async Task<IActionResult> Index1(string Appsearch)
        {
            ViewData["GetApplicationdetails"] = Appsearch;
            var appquery = from x in _context.Jobs select x;
            if (!String.IsNullOrEmpty(Appsearch))
            {
                appquery = appquery.Where(x => x.Employer.Contains(Appsearch));
            }
            return View(await appquery.AsNoTracking().ToListAsync());
        }
        */
        public IActionResult Search(string searchString)
        {
            IEnumerable<Job> jobs;
            string currentIndustry;

            if (string.IsNullOrEmpty(searchString))
            {
                jobs = _jobRepo.GetListOfJobs.OrderBy(j => j.JobId);
                currentIndustry = "All Industries";
            }
            else
            {
                jobs = _jobRepo.GetListOfJobs.Where(j => j.Employer.Contains(searchString) || j.Location.Contains(searchString));
                   
                currentIndustry = "All Industries"; ;
            }
            return View(new JobsListViewModel
            {
                Jobs = jobs,
                CurrentIndustry = currentIndustry
            });
        }

        public IActionResult Index(string industry)
        {
            IEnumerable<Job> jobs;
            string currentIndustry;

            if (string.IsNullOrEmpty(industry))
            {
                jobs = _jobRepo.GetListOfJobs.OrderBy(j=>j.JobId);
                currentIndustry = "All Industries";
            }
            else
            {
                jobs = _jobRepo.GetListOfJobs.Where(j => j.industry.IndustryType == industry)
                    .OrderBy(j => j.JobId);
                currentIndustry = _industryRepo.GetAllIndustries.FirstOrDefault(i => i.IndustryType == industry)?.IndustryType;
            }
            return View(new JobsListViewModel
            {
                Jobs = jobs,
                CurrentIndustry = currentIndustry
            });
        }

        public IActionResult Details(string role)
        {
            var job = _jobRepo.GetJobByRole(role);
            if (job == null)
                return NotFound();
            return View(job);
        }
    }
}
