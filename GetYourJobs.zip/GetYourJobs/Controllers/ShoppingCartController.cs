﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TopJobs.Models;
using TopJobs.ViewModels;

namespace TopJobs.Controllers
{
    public class ShoppingCartController : Controller
    {
        private readonly IServiceRepo _serviceRepo;
        private readonly ShoppingCart _shoppingCart;

        public ShoppingCartController(IServiceRepo serviceRepo, ShoppingCart shoppingCart)
        {
            _serviceRepo = serviceRepo;
            _shoppingCart = shoppingCart;
        }
        public IActionResult Index()
        {
            var items = _shoppingCart.GetShoppingCartItems();
            _shoppingCart.ShoppingCartItems = items;

            var shoppingCartViewModel = new ShoppingCartViewModel()
            {
                ShoppingCart = _shoppingCart,
                ShoppingCartTotal = _shoppingCart.GetShoppingCartTotal()

            };

            return View(shoppingCartViewModel);

        }

        public RedirectToActionResult AddToShoppingCart(int serviceid)
        {
            var selectedService = _serviceRepo.GetListOfServices.FirstOrDefault(s=>s.ServiceId == serviceid);
            if (selectedService != null)
            {
                _shoppingCart.AddToCart(selectedService, 3);
            }
            return RedirectToAction("Index");
        }

        public RedirectToActionResult RemoveFromShoppingCart(int serviceid)
        {
            var selectedService = _serviceRepo.GetListOfServices.FirstOrDefault(s=>s.ServiceId==serviceid);
            if (selectedService != null)
            {
                _shoppingCart.RemoveFromCart(selectedService);
            }
            return RedirectToAction("Index");
        }

    }
}
