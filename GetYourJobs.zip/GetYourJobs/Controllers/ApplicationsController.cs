﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TopJobs.Models;

namespace TopJobs.Controllers
{
    public class ApplicationsController : Controller
    {
        private readonly JobDbContext _context;

        public ApplicationsController(JobDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var applicant = new Applicant();
            return View(applicant);
        }

       

        [HttpPost]
        public IActionResult Index(Applicant applicant)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("Checkout");
            }
            return View();
            
        }


        public ActionResult Checkout()
        {
            ViewBag.CheckoutMsg = "Enjoy your Journey ! ";
            return View();

        }
    }
}
