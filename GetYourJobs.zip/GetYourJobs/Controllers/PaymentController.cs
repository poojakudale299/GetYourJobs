﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TopJobs.Models;

namespace TopJobs.Controllers
{
    public class PaymentController : Controller
    {
        private readonly JobDbContext _context;

        public PaymentController(JobDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Index(string Appsearch)
        {
            ViewData["GetApplicationdetails"] = Appsearch;
            var appquery = from x in _context.Jobs select x;
            if (!String.IsNullOrEmpty(Appsearch))
            {
                appquery = appquery.Where(x => x.Employer.Contains(Appsearch));
            }
            return View(await appquery.AsNoTracking().ToListAsync());
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
