﻿using TopJobs.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TopJobs.Models;

namespace EatFit.Controllers
{
    public class HomeController : Controller
    {
        private readonly IJobRepo _jobRepo;

        //DI
        public HomeController(IJobRepo jobRepo)
        {
            _jobRepo = jobRepo;

        }
        public IActionResult Index()
        {
            var homeViewModel = new HomeViewModel
            {
                HighestPayingJobs = _jobRepo.GetListOfJobs
            };
            return View(homeViewModel);
        }
    }
}
