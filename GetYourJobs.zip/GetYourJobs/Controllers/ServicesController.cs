﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TopJobs.Models;
using TopJobs.ViewModels;

namespace TopJobs.Controllers
{
    public class ServicesController : Controller
    {
        private readonly IServiceRepo _serviceRepo;

        public ServicesController(IServiceRepo serviceRepo)
        {
            _serviceRepo = serviceRepo;
        }
        public IActionResult Index()
        {
            IEnumerable<Service> services;

            services = _serviceRepo.GetListOfServices.OrderBy(s => s.ServiceName);
              
            return View(new ServicesListViewModel
            {
                Services = services
            });
        }

        public IActionResult Details(string serviceName)
        {
            var service = _serviceRepo.GetServiceByName(serviceName);
            if (service == null)
                return NotFound();
            return View(service);
        }
    }
}
